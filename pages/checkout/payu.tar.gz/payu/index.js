import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { useRouter } from 'next/router';
import classes from "~/styles/payment.module.css";
import customId from "custom-id-new";
import axios from "axios";
import { toast } from "react-toastify";
import {
  currencyConvert,
  discountPrice,
  postData,
} from "~/lib/clientFunctions";


const PaymentComponent = () => {
    const crypto = require("crypto");
  const [self, setSelf] = useState();
  const [post, setPost] = React.useState(null);
  const router = useRouter();
  const [isError, setIsError] = useState(false);
  const [loading, setLoading] = useState(false);
 const [oncheckOpen, setOnCheckOpen] = useState(false);
 const { session } = useSelector((state) => state.localSession);
  const cartData = useSelector((state) => state.cart);
  const settings = useSelector((state) => state.settings);
  const [orderIds, setOrderIds] = useState({ "orderId": "", "orderDocId": "" });
  const exchangeRate = settings.settingsData.currency.exchangeRate;
const [orderData, setOrderData] = useState({});
  const [hash, setHash] = useState();
   const [txtniddd, setTxtniddd] = useState();
   
  
// useEffect(() => {
//     if (cartData.items.length <= 0) {
//       router.replace("/checkout")
//     } 
//   }, [orderIds])

  
  const price = cartData.items.reduce(
    (accumulator, item) => accumulator + item.qty * item.price,
    0
  );
useEffect(() => {
    makePayment();
  },[]);
 // let reshash;  //hashvalue generated will be stored in this variable

const makePayment = async () => {
    await submitOrder();
    await paymentReq();
    //await responseReq();
  };
  //const discountPrice1 = cartData.deliveryInfo.cost + ((price - (cartData.coupon.discount / 100) * price) * 10) / 10;
  const discountPrice = 1;
  const trnId = "T" + customId({ randomLength: 4, upperCase: true });
  //const orderId = `R${customId({ randomLength: 4, upperCase: true })}`;
  // Create A Tmp Order 
 const submitOrder = async () => {
    try {
         const { coupon, items, billingInfo, shippingInfo, deliveryInfo } =
        cartData;
      const orderDatas = {
        coupon,
        products: items,
        billingInfo,
        shippingInfo,
        deliveryInfo,
        paymentData: {
          method: "Prepaid",
          id: trnId,
        },
      };
  const responseId = await axios.post("/api/checkout/payuOrderStore", JSON.stringify(orderDatas),
  {headers:{"Content-Type" : "application/json"}});
  //console.log("Payment Error:" + responseId.orderId);
  setTxtniddd(responseId.data.createdOrder);
    } catch(error) {
        console.log("OrderSave Error:" + error.responseId);
      //console.log("Payment Error:" + error.response.data);
    }
  };  

 const data = {
    txnid: '254411', //String
    amount: discountPrice,  //Float
    productinfo: txtniddd,  //String
    firstname: cartData.billingInfo.fullName,   //String
    email: cartData.billingInfo.email,  //String
  };
//This method will generate the hashvalue

  const paymentReq = async () => {
    try {
  const reshash = await axios.post("/api/checkout/payu", JSON.stringify(data),
  {headers:{"Content-Type" : "application/json"}});
  setHash(reshash.data.hash);
    } catch(error) {
        console.log("Payment Error:" + error);
      //console.log("Payment Error:" + error.response.data);
    }
  };
   
  

  var responseUrl = `${process.env.NEXT_PUBLIC_URL}/api/checkout/payuresponse`;
  
  return (
      <div>
      <div className="layout_top">
        <div className={classes.container}>
          <h2 className={classes.h2}>Pay Now</h2>
   <form method="post" action='https://secure.payu.in/_payment' >
<input type="hidden" name="key" value="WPBubxd5" />
<input type="hidden" name="txnid" value='254411' />
<input type="hidden" name="productinfo" value={txtniddd} />
<input type="hidden" name="amount" value={discountPrice}/>
<input type="hidden" name="email" value={cartData.billingInfo.email} />
<input type="hidden" name="firstname" value={cartData.billingInfo.fullName} />
<input type="hidden" name="lastname" value={cartData.billingInfo.fullName} />
<input type="hidden" name="surl" value={responseUrl} />
<input type="hidden" name="furl" value={responseUrl} />
<input type="hidden" name="phone" value={cartData.billingInfo.phone} />
<input type="hidden" name="hash" value={hash} />
<button className="sub_button" disabled={(loading && !isError)} type="submit">
              {loading ? "Processing" : "Pay Now"}
            </button>
            </form>
</div>
      </div>
    </div>
);
};

export default PaymentComponent;